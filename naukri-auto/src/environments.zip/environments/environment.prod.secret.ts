export const secretEnvironment = {
  googleClientId: '1079721870613-8s9r3idpedu0gdgl5umfaa0rhf4bimqg.apps.googleusercontent.com'
};
