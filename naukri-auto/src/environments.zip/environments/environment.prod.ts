export const environment = {
  production: true,
  googleClientId: ''
};